from typing import Dict, List, Optional, Union
from .utils import Joint, MovPointAdd, Point, Pose, ProgramInfo, SystemState
from ..utils import deprecated

VERSION: str
RELEASE_TIME: str


# CHAPTER 通信连接
def connect(ip: str, link_timeout: int = 2, retry_num: int = 5) -> int:
    """创建与指定控制器的 TCP 连接

    Args: 
        ip (str): 控制器IP地址
        link_timeout (int): 连接超时时间：默认`2`S,单位秒
        retry_num (int): 超时重连次数：默认`5`次

    Returns: 
        handle (int): 机器人句柄号
    """


def disconnect(handle: int) -> None:
    """删除与控制器的 TCP 连接

    Args: 
        handle (int): 机器人句柄号
    """


def get_ip_list() -> List[Dict[str, Union[str, int]]]:
    """获取可连接的一组控制器IP地址

    Returns: 
        List[Dict[str, Union[int, str]]]: 所有IP地址字符串的列表
    """


def get_ip_list_with_adapter() -> Dict[str, List[Dict[str, Union[str, int]]]]:
    """扫描可连接的机器人IP地址与对应适配器信息

    Returns: 
        Dict[str, List[Dict[str, Union[str, int]]]]: 该适配器对应的IP地址字符串的列表
    """


def get_version(handle: int) -> str:
    """获取版本信息

    Args: 
        handle (int): 机器人句柄号

    Returns:
        version (str): 版本信息字符串
    """


# CHAPTER IO信号


def get_do(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量的数字输出信号

    Args:
        handle (int): 机器人句柄号
        index (int, optional): DO端口号(0~247)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的DO数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个DO状态或DO状态列表(`1`：打开,`0`：关闭)
    """


def set_do(handle: int, index: int, state: int) -> None:
    """设置数字信号输出

    Args:
        handle (int): 机器人句柄号
        index (int): DO端口号(`0~247`)
        state (int): DO状态(`0`:关闭,`1`:打开)
    """


def wait_set_do_done(handle, timeout_ms: int = -1) -> None:
    """等待设置数字输出信号执行完成

    Args:
        handle (int): 机器人句柄号
        timeout_ms (int): 超时时间(ms): 超时时间.单位：ms. 默认-1表示无限等待
    """


def get_di(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量的数字输入信号

    Args:
        handle (int): 机器人句柄号
        index (int, optional): DI端口号(0~247)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的DI数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个DI状态或DI状态列表(`1`：打开,`0`：关闭)
    """


def get_force_di(handle: int,
                 index: Optional[int] = None,
                 count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量数字输入信号的强制状态

    Args:
        handle (int): 机器人句柄号
        index (int, optional): DI端口号(0~247)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的DI数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个强制DI状态或强制DI状态列表(`1`：已强制,`0`：未强制)
    """


def set_force_di(handle: int, index: int, data: Optional[int] = None) -> None:
    """设置或复位DI的值及强制状态

    Args:
        handle (int): 句柄号
        index (int): DI强制端口号(0~247)
        data (int,optional): DI状态值(0:打开, 1:关闭).不填则执行复位强制状态
    """


def get_ao(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量的模拟输出信号

    Args:
        handle (int): 机器人句柄号
        index (int, optional): AO端口号(0~15)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的AO数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个AO值或AO列表（单位：mV）
    """


def set_ao(handle: int, index: int, data: int) -> None:
    """设置指定模拟量输出端口电压值

    Args:
        handle (int): 机器人句柄号
        index (int): AO端口号(`0~15`)
        data (int): 指定AI电压值(依据"IO设定"模块的最值范围设定)，单位：mV 毫伏.
    """


def get_ai(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量的模拟输出信号

    Args:
        handle (int): 机器人句柄号
        index (int, optional): AI端口号(0~15)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的AI数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个AI值或AI列表（单位：mV）
    """


def get_force_ai(handle: int,
                 index: Optional[int] = None,
                 count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量模拟输入信号的强制状态

    Args:
        handle (int): 机器人句柄号
        index (int, optional): AI端口号(0~15)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的AI数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个强制AI状态或强制AI状态列表 (1: 已强制, 0: 未强制)
    """


def set_force_ai(handle: int, index: int, data: Optional[int] = None) -> None:
    """设置或复位AI的值及强制状态

    Args:
        handle (int): 句柄号
        index (int): AI端口号(0~15)
        data (int,optional): AI电压值, 单位：mv 毫伏.不填则执行复位强制状态
    """


def get_ei(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量的编码器输入值

    Args:
        handle (int): 机器人句柄号
        index (int, optional): EI端口号(0~7)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的EI数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个EI值或EI列表
    """


def reset_all_force_io(handle: int) -> None:
    """复位所有强制IO的值及强制状态

    Args:
        handle (int): 句柄号
    """


# CHAPTER 运动控制
def get_speed(handle: int) -> int:
    """获取系统全局速度百分比

    Args:
        handle (int): 机器人句柄号

    Returns:
        speed (int): 全局速度百分比(`1~100`),单位：%
    """


def set_speed(handle: int, scale: int) -> None:
    """设置系统全局速度百分比

    Args:
        handle (int): 机器人句柄号
        scale (int): 全局速度百分比(`1~100`),单位：%
    """


def movl(handle: int,
         point: Point,
         additional_data: Optional[MovPointAdd] = None) -> None:
    """沿笛卡尔空间以直线轨迹运动到目标点

    Args:
        handle (int): 机器人句柄号
        point (Point): 目标笛卡尔点位数据
        additional_data (MovPointAdd,optional): 附加动作数据
    """


def movc(handle: int,
         middle_point: Point,
         target_point: Point,
         central_angle: Optional[Union[float, int]] = None,
         additional_data: Optional[MovPointAdd] = None) -> None:
    """在笛卡尔空间坐标系下，沿以起始点、中间点和目标点确定的圆弧运动轨迹，经中间点运动到目标笛卡尔点位. 
    如果设置圆心角，则在三点确定的轨迹上，运动到按圆心角角度计算确定的笛卡尔点位

    Args:
        handle (int): 句柄号
        middle_point (Point): 中间点
        target_point (Point): 目标点
        central_angle (float): 圆心角。圆心角为0时执行标准MovC运动；圆心角为正值朝目标点运动.不能为负
        additional_data (MovPointAdd, optional): 附加动作(可选)
    """


def movj(handle: int,
         point: Union[Point, Joint],
         additional_data: Optional[MovPointAdd] = None) -> None:
    """沿关节空间以最快速度运动到目标点位

    Args:
        handle (int): 机器人句柄号
        point (Point/Joint): 目标笛卡尔或关节点位数据
        additional_data (MovPointAdd, optional): 附加动作参数
    """


def jump(handle: int,
         point: Point,
         jump_data: List[float],
         additional_data: Optional[MovPointAdd] = None) -> None:
    """沿笛卡尔空间以门型关节运动形式运动到目标笛卡尔点位

    Args:
        handle (int): 机器人句柄号
        point (Point): 笛卡尔点位数据
        jump_data (List[float]): 门型运动参数,长度为3的浮点数列表
        additional_data (MovPointAdd,optional): 附加动作参数
    """


def jumpl(handle: int,
          point: Point,
          jump_data: List[float],
          additional_data: Optional[MovPointAdd] = None) -> None:
    """沿笛卡尔空间以门型直线运动形式运动到目标笛卡尔点位

    Args:
        handle (int): 机器人句柄号
        point (Point): 笛卡尔点位数据
        jump_data (List[float]): 门型运动参数,长度为3的浮点数列表
        additional_data (MovPointAdd,optional): 附加动作参数
    """


def movsj(handle: int, joint: int, data: float) -> None:
    """在关节空间坐标系下,将单个关节轴运动到目标位置

    Args:
        handle (int): 机器人句柄号
        joint (int): 轴号(0:J1,1:J2,2:J3,3:J4,4:J5,5:J6,6:E1,7:E2,8:E3)
        data (float): 目标位置
    """


def jogl(handle: int,
         frame_direction: int,
         direction: int,
         type: int = 1,
         rtcp: int = 0):
    """在笛卡尔空间坐标系下,将末端沿指定方向进行持续运动

    Args:
        handle (int): 机器人句柄号
        frame_direction (int): 轴号(0:X,1:Y,2:Z,3:A,4:B,5:C)
        direction (int): 运动方向(0:正方向,1:负方向)
        type (int): 坐标系类型(1：世界坐标系,2：工具坐标系,3：用户坐标系)
        rtcp (int): 外部工具坐标系使用标识位(0:不使用  1:使用)
    """


def jogl_rel(handle: int,
             frame_direction: int,
             delta: float,
             type: int = 1,
             rtcp: int = 0) -> None:
    """在笛卡尔空间坐标系下,将末端沿指定方向进行增量运动

    Args:
        handle (int): 机器人句柄号
        frame_direction (int): 轴号(0:X,1:Y,2:Z,3:A,4:B,5:C)
        delta (float): 增量值
        type (int): 坐标系类型(1：世界坐标系,2：工具坐标系,3：用户坐标系)
        rtcp (int): 外部工具坐标系使用标识位(0:不使用  1:使用)
    """


#NOTE - 关节空间单向持续运动
def jogj(handle: int, frame_direction: int, direction: int, rtcp: int = 0):
    """关节单向持续运动
    在关节坐标系下,将末端沿指定方向进行持续运动

    Args:
        handle (int): 机器人句柄号
        frame_direction (int): 坐标系方向(0:J1，1:J2，2:J3，3:J4，4:J5，5:J6, 6:E1, 7:E2, 8:E3)
        direction (int): 运动方向(0:正方向,1:负方向)
        rtcp (int): 外部工具坐标系使用标识位(0:不使用  1:使用)
    """


#NOTE - 关节空间单向增量运动
def jogj_rel(handle: int, frame_direction: int, delta: float, rtcp: int = 0):
    """关节单向增量运动
    在关节坐标系下,将末端沿指定方向进行增量运动

    Args:
        handle (int): 机器人句柄号
        frame_direction (int): 坐标系方向(0:J1，1:J2，2:J3，3:J4，4:J5，5:J6, 6:E1, 7:E2, 8:E3)
        delta (int): 增量值
        rtcp (int): 外部工具坐标系使用标识位(0:不使用  1:使用)
    """


def servoj(handle: int, joint: Joint, cmdt: float, lookahead: int, gain: int,
           vel: int, acc: int) -> None:
    """实时控制关节位置

    Args:
        handle (int): 机器人句柄号
        joint (Joint): 关节位置值(j1~e3)
        cmdt (float): 指令周期，最小参数 0.002, 单位[s]
        lookahead (int): 暂未使用
        gain (int): 跟随目标位置的比例增益参数，范围[0-50]
        vel (int): 速度，范围[0,100]，单位[%]
        acc (int): 加速度，范围[0,100]，单位[%]
    """


def servol(handle: int, point: Point, cmdt: float, lookahead: int, gain: int,
           vel: int, acc: int) -> None:
    """实时控制 TCP 位置
    
    Args:
        handle (int): 机器人句柄号
        point (Point): 笛卡尔位置值与姿态值(x,y,z,a,b,c,e1,e2,e3;uf;tf;cfg)
        cmdt (float): 指令周期，最小参数 0.002, 单位[s]
        lookahead (int): 暂未使用
        gain (int): 跟随目标位置的比例增益参数，范围[0-50]
        vel (int): 速度，范围[0,100]，单位[%]
        acc (int): 加速度，范围[0,100]，单位[%]
    """


def wait_move_done(handle: int, timeout_ms: int = -1) -> None:
    """等待运动完成
    等待运动命令执行完成

    Args:
        handle (int): 机器人句柄号
        timeout_ms (int, optional):  超时时间.单位：ms. 默认-1表示无限等待
    """


# CHAPTER 坐标系管理
def get_uf(handle: int, index: int) -> Pose:
    """获取指定用户坐标系数据

    Args:
        handle (int): 机器人句柄号
        index (int): 用户坐标系序号(`0~16`)

    Returns:
        pose (Pose): 用户坐标系数据
    """


def set_uf(handle: int, index: int, data: Pose) -> None:
    """设置指定用户坐标系数据

    Args:
        handle (int): 机器人句柄号
        index (int): 用户坐标系序号(`1~16`)。uf=0不允许设置。
        data (Pose): 位姿数据
    """


def get_ufno(handle: int) -> int:
    """获取当前使用的用户坐标系序号

    Args:
        handle (int): 机器人句柄号

    Returns:
        index (int): 坐标系序号(`0~16`)
    """


def set_ufno(handle: int, index: int) -> None:
    """设置当前使用的用户坐标系序号

    Args:
        handle (int): 机器人句柄号
        index (int): 用户坐标系序号(`0~16`)
    """


def get_tf(handle: int, index: int) -> Pose:
    """获取指定工具坐标系数据

    Args:
        handle (int): 机器人句柄号
        index (int): 工具坐标系序号(`0~16`)

    Returns:
        pose (Pose): 工具坐标系数据
    """


def set_tf(handle: int, index: int, data: Pose) -> None:
    """设置指定工具坐标系数据

    Args:
        handle (int): 机器人句柄号
        index (int): 工具坐标系序号(`1~16`)。tf=0不允许设置。
        data (Pose): 位姿数据
    """


def get_tfno(handle: int) -> int:
    """获取当前使用的工具坐标系序号

    Args:
        handle (int): 机器人句柄号

    Returns:
        index (int): 工具坐标系序号(`0~16`)
    """


def set_tfno(handle: int, index: int) -> None:
    """设置当前使用的工具坐标系序号

    Args:
        handle (int): 机器人句柄号
        index (int): 工具坐标系序号(`0~16`)
    """


def get_bf(handle: int) -> Pose:
    """获取指定工具坐标系数据

    Args:
        handle (int): 机器人句柄号

    Returns:
        pose (Pose): 基坐标系数据
    """


def get_wf(handle: int) -> Pose:
    """获取基坐标系 [弃用，请使用`get_bf`]

    Args:
        handle (int): 机器人句柄号

    Returns:
        pose (Pose): 基坐标系数据
    """


def set_bf(handle: int, data: Pose) -> None:
    """设置基坐标系数据

    Args:
        handle (int): 机器人句柄号
        data (Pose): 位姿数据
    """


@deprecated("set_bf")
def set_wf(handle: int, pose: Pose) -> None:
    """设置基坐标系数值 [弃用，请使用`set_bf`]

    Args:
        handle (int): 机器人句柄号
        pose (Pose): 位姿数据
    """


# CHAPTER 变量管理


def get_hr(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[float, List[float]]:
    """获取一定数量的HR变量

    Args:
        handle (int): 机器人句柄号
        index (int, optional): HR变量序号 (0~999)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的HR数量 (1~1000)
            仅当index存在时可指定，默认为1
            
    Returns:
        value (float | List[float]): 单个HR值或HR列表
    """


get_hr_list = get_hr


def set_hr(handle: int, index: int, values: Union[float, List[float]]) -> None:
    """设置一定数量的HR变量

    Args:
        handle (int): 机器人句柄号
        index (int): 变量序号 (0~999)
        values (Union[float, List[float]]): 单个HR值或HR列表
    Examples:
        >>> # 设置HR[6]~HR[11]:
        >>> values = []
        >>> for i in range(6):
        >>>     values[i] = i
        >>> set_hr(handle, 6, values)
    """


set_hr_list = set_hr


@deprecated("set_hr")
def set_all_hr(
    handle: int,
    values: List[float],
) -> None:
    """设置所有HR变量 [弃用，请使用`set_hr`]

    Args:
        handle (int): 机器人句柄号
        values (List[float]): HR变量值列表
    """


def get_pr_list(
    handle: int,
    index: int,
    length: int,
) -> List[Point]:
    """获取一定数量的PR变量

    Args:
        handle (int): 机器人句柄号
        index (int): 变量起始编号
        length (int): 获取个数
    
    Returns:
        value (List[Point]): 变量列表
    """


def get_pr(handle: int,
           index: Optional[int] = None,
           count: Optional[int] = None) -> Union[Point, List[Point]]:
    """获取一定数量的PR变量

    Args:
        handle (int): 机器人句柄号
        index (int, optional): PR变量序号 (0~999)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的PR数量 (1~1000)
            仅当index存在时可指定，默认为1
    
    Returns:
        value (Point | List[Point]): 单个PR值或PR列表
    """


get_pr_list = get_pr

get_penv = get_pr
get_penv_list = get_pr


def set_pr(handle: int, index: int, points: Union[Point, List[Point]]) -> None:
    """设置一定数量的PR变量

    Args:
        handle (int): 机器人句柄号
        index (int): 变量序号 (0~999)
        values (Union[Point, List[Point]]): 单个PR值或PR列表
    """


set_pr_list = set_pr

set_penv = set_pr


def get_jpr(handle: int,
            index: Optional[int] = None,
            count: Optional[int] = None) -> Union[Joint, List[Joint]]:
    """获取一定数量的JPR变量

    Args:
        handle (int): 机器人句柄号
        index (int, optional): JPR变量序号 (0~63)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的JPR数量 (1~64)
            仅当index存在时可指定，默认为1
    
    Returns:
        value (Joint | List[Joint]): 单个JPR值或JPR列表
    """


get_jpr_list = get_jpr

get_jpenv = get_jpr
get_jpenv_list = get_jpr


def set_jpr(handle: int, index: int, joints: Union[Joint,
                                                   List[Joint]]) -> None:
    """设置一定数量的JPR变量

    Args:
        handle (int): 机器人句柄号
        index (int): 变量序号 (0~63)
        values (Union[Joint, List[Joint]]): 单个JPR值或JPR列表
    """


set_jpr_list = set_jpr

set_jpenv = set_jpr


def get_mbr(handle: int,
            index: Optional[int] = None,
            count: Optional[int] = None) -> Union[int, List[int]]:
    """获取一定数量的MBR值

    Args:
        handle (int): 机器人句柄号
        index (int, optional): MBR端口号(0~99)
            不传时获取所有端口，传入时需与count组合使用
        count (int, optional): 要获取的MBR数量
            仅当index存在时可指定，默认为1

    Returns:
        Union[int, List[int]]: 单个MBR值或MBR列表
    """


def set_mbr(handle: int, index: int, data: int) -> None:
    """设置 MBR 寄存器数据

    Args:
        handle (int): 机器人句柄号
        index (int): MBR寄存器序号(`0-99`)
        data (int): MBR寄存器数值
    """


# CHAPTER 系统状态
def get_cpoint(handle: int) -> Point:
    """获取当前用户与工具坐标系下的笛卡尔点位数据

    Args:
        handle (int): 机器人句柄号

    Returns:
        point (Point): 笛卡尔点位数据
    """


def get_wpoint(handle: int) -> Point:
    """获取当前世界坐标下的笛卡尔点位数据

    Args:
        handle (int): 机器人句柄号

    Returns:
        point (Point): 笛卡尔点位数据
    """


def get_cjoint(handle: int) -> Joint:
    """获取当前关节点位数据

    Args:
        handle (int): 机器人句柄号

    Returns:
        joint (Joint): 点位数值
    """


def get_system_state(handle: int) -> SystemState:
    """获取系统的基本状态

    Args:
        handle (int): 机器人句柄号

    Returns:
        state (SystemState): 系统状态。详情查看数据结构 SystemState 结构体
    """


def set_system_mode(handle: int, mode: int) -> None:
    """设置系统当前运行模式

    Args:
        handle (int): 机器人句柄号
        mode (int): `SYSTEM_MODE_AUTO`=`2`:自动模式, `SYSTEM_MODE_MANUAL`=`3`:手动模式,
         `SYSTEM_MODE_DEBUG`=`5`:调试模式, `SYSTEM_MODE_AUTOCMD`=`100`:自动命令模式
    """


def set_remote(handle: int, is_remote: bool) -> None:
    """设置系统远程状态

    Args:
        handle (int): 机器人句柄号
        is_remote (bool): 远程状态(`True`: 远程模式,`False`: 本地模式)
    """


def enable_servo(handle: int, is_servo_on: bool) -> None:
    """设置系统使能状态

    Args:
        handle (int): 机器人句柄号
        is_servo_on (bool): (True:上使能,False:下使能)
    """


@deprecated("enable_servo")
def servo_enable(handle: int, is_servo_on: bool) -> None:
    """旧的启用伺服接口，已弃用，请使用 enable_servo"""


def set_path_back_type(handle: int, type: int = 1) -> None:
    """设置停止再启动返回方式
    手动移动后，设置再启动时是否返回原停止位置. 搭配 start 接口使用
    Args:
        handle (int): 机器人句柄号
        type (int): 返回方式: 0-不返回停止位置，1-返回停止位置
    """


def run(handle: int,
        program_name: Optional[str] = None,
        start_line: Optional[int] = 1) -> None:
    """自动运行程序

    Args:
        handle (int): 机器人句柄号
        program_name (str,optional): 目标程序名称(不带后缀),默认空时从主程序开始运行
        start_line (int,optional): 程序启动行号(首行为1),默认从首行1开始
    """


def start(handle: int) -> None:
    """停止再启动, 开始运行程序
    1. 可使用 set_path_back_type 接口，设置当程序停止再启动时是否返回原停止位置(如果可以被设置但用户未设置, 内部默认选择[返回原停止位置])
    2. 默认从当前程序当前行运行
    Args:
        handle (int): 机器人句柄号
    """


def pause(handle: int) -> None:
    """暂停运行当前程序或运动

    Args:
        handle (int): 机器人句柄号
    """


def resume(handle: int) -> None:
    """恢复运行当前程序或运动

    Args:
        handle (int): 机器人句柄号
    """


def stop(handle: int) -> None:
    """停止运行当前程序或运动

    Args:
        handle (int): 机器人句柄号
    """


@deprecated("stop")
def stop_move(handle: int) -> None:
    """停止机器人手动运动 [弃用, 请使用 `stop`]

    Args:
        handle (int): 机器人句柄号
    """


def get_module_name_list(handle: int) -> list[str]:
    """获取模块名列表
    
    Args:
        handle (int): 机器人句柄号
    Returns:
        module_name_list (list[str]): 模块名列表
    """


def load_module(handle: int, module_name: str) -> None:
    """加载模块
    
    Args:
        handle (int): 机器人句柄号
        module_name (int): 模块名, 如"test"
    """


def get_compile_state(handle: int) -> int:
    """获取系统程序编译状态
    
    Args:
        handle (int): 机器人句柄号
    Returns:
        state (int): 系统编译状态 (0:未编译, 1:编译中, 2:已编译) 编译失败会置为0
    """


def get_program_info(handle: int) -> List[ProgramInfo]:
    """获取当前模块的程序信息

    Args:
        handle (int): 机器人句柄号
    Returns:
        programs (List[ProgramInfo]): 程序信息列表
    """


def daemon_run(handle: int, name: str) -> None:
    """运行后台任务
    
    Args:
        handle (int): 机器人句柄号
        name (str): 任务名, 如"test"
    """


def daemon_pause(handle: int, name: str) -> None:
    """暂停后台任务
    Args:
        handle (int): 机器人句柄号
        name (str): 任务名, 如"test"
    """


@deprecated("daemon_run")
def daemon_resume(handle: int, name: str) -> None:
    """恢复运行后台任务 [弃用，请使用`daemon_run`]
    Args:
        handle (int): 机器人句柄号
        name (str): 任务名, 如"test"
    """


def daemon_stop(handle: int, name: str = None) -> None:
    """停止后台任务
    Args:
        handle (int): 机器人句柄号
        name (str): 任务名, 如"test". 若不传入，则默认停止所有任务
    """


def get_system_alarm_info(handle: int) -> List[Dict[str, Union[int, str]]]:
    """获取系统报警码

    Args:
        handle (int): 机器人句柄号

    Returns:
        error_index (List[Dict[str, Union[int, str]]]): 报警信息队列
    """


def abort(handle: int) -> None:
    """停止系统当前运行操作
    注意：无法停止静态后台程序
    Args:
        handle (int): 机器人句柄号
    """


def reset(handle: int) -> None:
    """系统报警复位

    Args:
        handle (int): 机器人句柄号
    """


# CHAPTER 视觉工艺
def vision_static_cnvrt(handle: int, vision_index: int, pixel: Pose) -> Pose:
    """计算静态视觉转换后的点位
    注意：可通过 get_last_error 接口获取执行结果的错误信息
    Args:
        handle (int): 机器人句柄号
        vision_index (int): 视觉工艺号(0~7)
        pixel (Pose): 视觉像素坐标点的位姿数据，包含u,v,c等参数
    Returns:
        pose (Pose): 经过静态视觉转换后的点位
    """


def vision_dynamic_cnvrt(handle: int, vision_index: int, pixel: Pose,
                         trig_point: Point) -> Pose:
    """计算动态视觉转换后的点位
    注意：可通过 get_last_error 接口获取执行结果的错误信息
    Args:
        handle (int): 机器人句柄号
        vision_index (int): 视觉工艺号(0~7)
        pixel (Pose): 视觉像素坐标点的位姿数据, 包含u,v,c等参数
        trig_point (Point): 视觉拍照点的点位数据，用于辅助计算动态视觉转换
    Returns:
        pose (Pose): 经过动态视觉转换后的位姿数据
    """


# CHAPTER 坐标系标定
def calc_uf(handle: int, poses: list[Pose], origin: bool, tilt: bool) -> Pose:
    """标定用户坐标系
    注意，标定成功但倾斜角度大于10°会返回异常
    Args:
        handle (int): 机器人句柄号
        poses (list[Pose]): 记录Tcp在世界(uf0)的坐标列表。 标定点位个数 (1点/2点/3点)
        origin (bool): 第一个点是否确认为坐标系原点  (False:不确认为原点, True:确认为原点)
        tilt (bool): 坐标系是否倾斜 (False:不倾斜, True:倾斜)

    Returns:
        result (Pose): 标定后的用户坐标系 (x,y,z,a,b,c)
    """


def calc_tf(handle: int, poses: list[Pose]) -> tuple[Pose, list[float]]:
    """标定工具坐标系
    注意，标定成功但倾斜角度大于10°会抛出异常
    Args:
        handle (int): 机器人句柄号
        poses (list[Pose]): 记录法兰(tf0)在同一用户的坐标列表
         标定点位个数：
            3点: 4自由度 同一位置任意姿态三点 标定XY偏移量
            4点: 4自由度/6自由度 标定XYZ方向偏移量
            5点: 四自由度  标定XY偏移量和姿态ABC, 其中第4点沿Z方向移动，第5点沿着X方向移动
            6点: 四自由度/6自由度 标定XYZ方向偏移量和姿态ABC, 其中第5点沿Z方向移动，第6点沿着X方向移动
            8点: 6自由度 标定XYZ方向偏移量
            10点: 6自由度 标定XYZ方向偏移量和姿态ABC, 其中第9点沿Z方向移动，第10点沿着X方向移动
    Returns:
        tuple[Pose, list[float]]:
            result (Pose): 标定后的工具坐标系 (x,y,z,a,b,c)
            errors (bool): 标定误差(err,0,0)
    """


def calc_2p_tf(handle: int, target_pose: Pose, teach_pose: Pose) -> Pose:
    """根据已知目标点，标定工具坐标系
    注意：1.可通过 get_last_error 接口获取标定错误信息
    2. 标定成功但倾斜角度大于10°会返回异常
    Args:
        handle (int): 机器人句柄号
        target_pose (Pose): 目标点位。已知目标点位在用户的坐标 (x,y,z,a,b,c) 
        teach_pose (Pose): 示教点位。记录法兰(tf0)在同一用户的坐标 (x,y,z,a,b,c)

    Returns:
        pose (Pose): 标定后的工具坐标系 (x,y,z,a,b,c)
    """


# CHAPTER API日志管理


def logger_shutdown() -> None:
    """释放日志缓存资源
    注意：API内部会自动调用该接口以释放日志资源，若用户在主程序退出时遇到程序挂起问题，可手动调用该接口;
    """


def logger_get_recent_errors() -> list[str]:
    """获取最近多条错误日志
    需确保API日志已开启
    Returns:
        errors (list[str]): 错误日志。最多20条。
    """


def get_last_error() -> str:
    """获取最后一次API错误
    Returns:
        msg (str): API错误
    """


# CHAPTER 坐标系转换
def cnvrt_j(handle: int, src_point: Point, inverse_type: int,
            last_joint: Joint) -> Joint:
    """笛卡尔点位逆解求关节点位
    
    Args:
        handle (int): 机器人句柄号
        src_point (Point): 需逆解求关节坐标的笛卡尔点位
        inverse_type (int): 模式选择参数(逆解类型)。 0-OnlyConf, 1-Conf&Turn, 2-Shortest, 3-Conf&FreeEndTurn
        last_joint (Joint): 笛卡尔点位 src_point 的上一个关节点位

    Returns:
        dest_joint (Joint): 逆解求出的目标关节点位
    """


def cnvrt_p(handle: int, src_joint: Joint, uf: int, tf: int) -> Point:
    """关节点位正解求笛卡尔点位
    
    Args:
        handle (int): 机器人句柄号
        src_joint (Joint): 需正解求笛卡尔点位的关节点位
        uf (int): 用户坐标系编号 (0~16, 0表示世界坐标系)
        tf (int): 工具坐标系编号 (0~16, 0表示法兰盘坐标系)

    Returns:
        dest_point (Point): 正解求出的目标笛卡尔点位
    """


def cnvrt_p_to_p(handle: int, source_point: Point, target_uf: int,
                 target_tf: int) -> Point:
    """笛卡尔点位坐标系转换
    
    Args:
        handle (int): 机器人句柄号
        source_point (Point): 源笛卡尔位置点位
        target_uf (int): 转换后点位的用户坐标系编号 (0~16, 0 表示世界坐标系)
        target_tf (int): 转换后点位的工具坐标系编号 (0~16, 0 表示法兰盘坐标系)

    Returns:
        target_point (Point): 转换后的笛卡尔位置点位
    """


# CHAPTER 反馈字符串接口
def enable_read_message_thread(handle: int, enable: bool) -> None:
    """控制字符串读取线程是否开启
    
    Args:
        handle (int): 机器人句柄号
        enable (bool): 是否开启
    """


def get_lua_message(handle: int, read_buffer_size: int) -> tuple[str, int]:
    """获取Lua反馈字符串
    
    Args:
        handle (int): 机器人句柄号
        read_buffer_size (int): 读取buffer大小
    Returns:
        value (tuple[str,int]) 
        value[0]: data (str): 反馈字符串
        value[1]: left_data_length (int): 剩余字符串数据长度
    Notes:
        1. 调用前需确保enable_read_message_thread()已开启
        2. 若left_data_length大于0, 则用户需继续执行该接口以获取剩余字符串    
    """


def export_api_log_file(zip_path: str) -> None:
    """导出API日志文件
    ！！需确保开启API[文件日志]记录功能（运行前修改dll同级目录下的xapi.ini，随后执行logger_init()）
    Args:
        zip_path (str): 压缩包导出路径 如"/path/to/xapi_logs.zip"
    """


# CHAPTER 高级接口
@deprecated("execute_lua")
def lua_execute(handle: int, lua_cmd: str) -> None:
    """旧接口，已弃用，请使用 `execute_lua`"""


def execute_lua(handle: int, lua_cmd: str) -> None:
    """执行lua命令

    Args:
        handle (int): 机器人句柄号
        lua_cmd (str): lua命令
    """


def wait_cmd_send_done(handle: int) -> None:
    """等待命令下发完成
    注意：该函数不保证机器人执行完成命令，仅保证命令已发送到机器人
    Args:
        handle (int): 机器人句柄号
    """


def enable_debug_output(enable: bool) -> None:
    """是否输出高级调试信息

    Args:
        enable (bool): `True`:输出,`False`:不输出
    """


def enable_time_high_period(enable: bool) -> None:
    """控制API是否开启高精度定时器模式（仅Windows）
    推荐ServoJ、ServoL函数开启
    注意：该函数可能导致CPU等占有率过高！！程序正常退出会主动关闭高精度定时器模式。
    Args:
        enable (bool): `True`:开启,`False`:关闭
    """
