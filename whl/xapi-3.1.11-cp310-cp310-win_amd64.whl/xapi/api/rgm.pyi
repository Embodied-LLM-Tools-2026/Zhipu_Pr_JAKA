from dataclasses import dataclass

from .utils import Joint, Point


@dataclass
class RGMRobState:
    """实时引导运动模式，机器人状态

    :_fields_:
        - state (int): 机器人实时引导运动状态 (0:停止 1:准备 2:运行中 3:暂停)
        - point (Point): 机器人当前笛卡尔位置
        - joint (Joint): 机器人当前关节位置
    """
    state: int
    point: Point
    joint: Joint


def rgm_callback(func):
    """
    装饰器：将用户回调函数转换为 RGM 兼容的回调函数
    自动处理指针解引用，让用户直接操作 Python 对象
    """


# SECTION - 实时引导运动
# NOTE - RGM 初始化
def rgm_init(handle: int, port: int, cycle_rate: int, user_func) -> None:
    """RGM 初始化
    RGM 参数初始化
    
    Args:
        handle (int): 机器人句柄号 
        port (int): 端口号，范围 50200 ~ 50209
        cycle_rate (int): 控制周期 2ms*cycle_rate，范围 1 ~ 10，最小控制周期 2ms；
        user_func (RGMCallback): 用户回调函数
    """


# NOTE - RGM 销毁
def rgm_destroy(handle: int) -> None:
    """RGM 销毁
    RGM 销毁，退出程序或再次使用 rgm_init 前，建议使用本接口回收资源

    Args:
        handle (int): 机器人句柄号 
    """


# NOTE - RGM 启动
def rgm_start(handle: int) -> None:
    """RGM 启动
    启动 RGM 功能，系统进入到 RGM 模式，并建立通讯连接。通过 SystemState 获取当前系统是否处于 RGM 模式。
    注意: 阻塞接口，内部需等待机器人进入RGM模式(约2000ms超时)
    
    Args:
        handle (int): 机器人句柄号
    """


# NOTE - RGM 停止
def rgm_stop(handle: int) -> None:
    """RGM 停止
    停止 RGM 功能，系统退出 RGM 模式，并断开通讯连接。
    注意：阻塞接口，内部需等待机器人退出RGM模式(约2000ms超时)
    
    Args:
        handle (int): 机器人句柄号
    """


# NOTE - RGM 实时关节位置运动
def rgm_servoj(handle: int, joint: Joint, cmdt: float, lookahead: float,
               gain: float, vel: float, acc: float) -> None:
    """RGM 实时关节位置运动
    RGM 模式下，实时引导控制关节位置运动。

    Args:
        handle (int): 机器人句柄号
        joint (Joint): 目标关节点位，具体内容请参考 Joint 结构体
        cmdt (float): 指令最小执行时间，范围 0.0 ~ 2.0，单位[s]
        lookahead (float): 暂未使用
        gain (float): 跟随目标位置的比例增益参数，范围 0.0 ~ 50.0，值越大机器人反应越快，但可能导致不稳定振动。
        vel (float): 速度，范围 0.0 ~ 100.0，单位[%]
        acc (float): 加速度，范围 0.0 ~ 100.0，单位[%]
    """


# NOTE - RGM 实时 TCP 位置运动
def rgm_servol(handle: int, point: Point, cmdt: float, lookahead: float,
               gain: float, vel: float, acc: float) -> None:
    """RGM 实时 TCP 位置运动
    RGM 模式下，实时引导控制 TCP 位置运动。
    
    Args:
        handle (int): 机器人句柄号
        point (Point): 目标笛卡尔点位，具体内容请参考 Point 结构体
        cmdt (float): 指令最小执行时间，范围 0.0 ~ 2.0，单位[s]
        lookahead (float): 暂未使用
        gain (float): 跟随目标位置的比例增益参数，范围 0.0 ~ 50.0，值越大机器人反应越快，但可能导致不稳定振动。
        vel (float): 速度，范围 0.0 ~ 100.0，单位[%]
        acc (float): 加速度，范围 0.0 ~ 100.0，单位[%]
    """
