import ctypes
from typing import Any

DI_NUM: int
DO_NUM: int
AI_NUM: int
AO_NUM: int
EI_NUM: int

R_NUM: int
HR_NUM: int
PR_NUM: int
JPR_NUM: int
MBR_NUM: int

SYSTEM_MODE_AUTO: int
SYSTEM_MODE_MANUAL: int
SYSTEM_MODE_DEBUG: int
SYSTEM_MODE_AUTOCMD: int


class RobException(Exception):
    """自定义异常类

    Args:
        Exception (Exception): 继承父类Exception
    """
    api_name: str
    error_code: int
    error_symbol: str
    error_message: str

    def __init__(self, api_name, error_code, error_symbol,
                 error_message) -> None:
        ...


class IPAddr(ctypes.Structure):
    """扫描IP

    :fields:
        - net_no (int): 网口号(网口0，网口1)
        - ip (str): IP地址
    """
    net_no: str
    ip: str


class Pose(ctypes.Structure):
    """笛卡尔位置

    :fields:
        - x (float): 笛卡尔坐标系 X 轴
        - y (float): 笛卡尔坐标系 X 轴
        - z (float): 笛卡尔坐标系 Z 轴
        - a (float): 绕 X 轴的旋转值
        - b (float): 绕 Y 轴的旋转值
        - c (float): 绕 Z 轴的旋转值
        - e1 (float): 外部附加轴1
        - e2 (float): 外部附加轴2
        - e3 (float): 外部附加轴3
        - precision(int): 数据精度。默认保留6位小数
    """
    # 数据精度。默认保留6位小数
    precision: int
    x: float
    y: float
    z: float
    a: float
    b: float
    c: float
    e1: float
    e2: float
    e3: float

    def __init__(self,
                 x: float = 0.0,
                 y: float = 0.0,
                 z: float = 0.0,
                 a: float = 0.0,
                 b: float = 0.0,
                 c: float = 0.0,
                 e1: float = 0.0,
                 e2: float = 0.0,
                 e3: float = 0.0,
                 **kwargs) -> None:
        ...

    def tolist(self):
        ...


class Joint(ctypes.Structure):
    """机器人关节点位

    :fields:
        - j1 (float): 关节轴1
        - j2 (float): 关节轴2
        - j3 (float): 关节轴3
        - j4 (float): 关节轴4
        - j5 (float): 关节轴5
        - j6 (float): 关节轴6
        - e1 (float): 外部附加轴1
        - e2 (float): 外部附加轴2
        - e3 (float): 外部附加轴3
        - precision(int): 数据精度。默认保留6位小数
    """
    # 数据精度。默认保留6位小数
    precision: int
    j1: float
    j2: float
    j3: float
    j4: float
    j5: float
    j6: float
    e1: float
    e2: float
    e3: float

    def __init__(self,
                 j1: float = 0.0,
                 j2: float = 0.0,
                 j3: float = 0.0,
                 j4: float = 0.0,
                 j5: float = 0.0,
                 j6: float = 0.0,
                 e1: float = 0.0,
                 e2: float = 0.0,
                 e3: float = 0.0,
                 **kwargs) -> None:
        ...

    def tolist(self):
        ...


class Point(ctypes.Structure):
    """机器人笛卡尔点位

    :fields:
        - pose (Pose): 位姿点位数据
        - uf (int): 用户坐标系序号
        - tf (int): 工具坐标系序号
        - cfg (int * 4): 位姿数据
    """
    pose: Pose
    uf: int
    tf: int
    cfg: tuple

    def __init__(self,
                 pose=...,
                 uf: int = 0,
                 tf: int = 0,
                 cfg=(0, 0, 0, 0),
                 **kwargs: Any) -> None:
        ...

    def tolist(self):
        ...


class MovPointAdd(ctypes.Structure):
    """ 运动点位附加动作数据

    :fields:
        - vel (int): 速度百分比（1%~100%)
        - cnt (int): 定位类型(-1:Fine; 0~100:Cnt)
        - acc (int): 加速度百分比（1%~100%)
        - dec (int): 减速度百分比（1%~100%)
        - offset (int): 位置补偿(-2:不使用; -1:Offset常量)
        - toffset (int): 刀具补偿(-2:不使用; -1:Toffset常量)
        - vision_num (int): 视觉工艺-视觉补偿序号(-1:不使用; 0~7:视觉工艺补偿序号)
        - track_num (int): 跟踪工艺序号(-1:不使用; 0~7:跟踪工艺序号)
        - wrist (int): 腕部动作(0:不使用; 1:腕部动作类型)
        - inc (int): 增量动作(0:不使用; 1:使用)
        - search (int): 搜索动作(0:不使用; 1:使用)
        - rtcp (int): 外部刀具设置(0:不使用; 1:使用
        - offset_data (Pose): offset 位姿数据 (仅当使用 offset 常量(offset = -1)时有效)
        - toffset_data (Pose): toffset 位姿数据 (仅当使用 toffset 常量(toffset = -1)时有效)
    """
    precision: int
    vel: int
    cnt: int
    acc: int
    dec: int
    offset: int
    toffset: int
    vision_num: int
    track_num: int
    wrist: int
    inc: int
    search: int
    rtcp: int
    offset_data: Pose
    toffset_data: Pose

    def __init__(self,
                 vel: int = 100,
                 cnt: int = 0,
                 acc: int = 100,
                 dec: int = 100,
                 offset: int = -2,
                 toffset: int = -2,
                 vision_num: int = -1,
                 track_num: int = -1,
                 wrist: int = 0,
                 inc: int = 0,
                 search: int = 0,
                 rtcp: int = 0,
                 offset_data=(0, 0, 0, 0, 0, 0, 0, 0, 0),
                 toffset_data=(0, 0, 0, 0, 0, 0, 0, 0, 0),
                 **kwargs) -> None:
        ...

    def data_init(self) -> None:
        ...

    def tolist(self):
        ...


class SystemState(ctypes.Structure):
    """系统状态

    :fields:
        - run (int): 运行状态
        - mode (int): 系统模式
        - in_pos (int): 轴到位信号
        - alarm (int): 报警状态
        - remote (int): 远程状态
        - link (int): 通信连接状态
        - enable (int): 使能状态
        - cmd_que (int): 命令队列满标识位
        - rgm_state (int): 系统 RGM 模式标识位
    """
    run: int
    mode: int
    in_pos: int
    alarm: int
    remote: int
    link: int
    enable: int
    cmd_que: int
    rgm_state: int

    def __init__(self) -> None:
        ...

    def tolist(self):
        ...


class SystemAlarmParam(ctypes.Structure):
    """系统报警信息单元

    :_fields_:
        - level (int): 报警等级
        - type (int): 报警类别码
        - code (int): 具体报警码
        - content (str): 报警内容
        - reason (str): 报警原因
        - solution (str): 报警处理方法
    """
    level: int
    type: int
    code: int
    content: str
    reason: str
    solution: str

    def tolist(self):
        ...


class SystemAlarmInfo(ctypes.Structure):
    """系统报警信息队列

    :_fields_:
        - param (SystemAlarmParam * 20): 系统报警信息单元
    """
    param: tuple

    def tolist(self):
        ...


class ProgramInfo(ctypes.Structure):
    """程序信息

    :_fields_:
        - name (char * 64): 程序名称
        - priority (int): 优先级 (0:前台程序 1~5:后台程序)
        - type (int): 程序类型 (0:前台程序 1:静态任务[后台自动运行] 2:动态任务[随主程序启动后运行] 3:指令任务[指令调用])
        - state (int): 运行状态 (1:运行 2:暂停 3:停止)
    """
    name: str
    priority: int
    type: int
    state: int
